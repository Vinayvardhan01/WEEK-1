#===========         week-3  ==================
import pandas as pd
from sklearn.preprocessing import LabelEncoder, MinMaxScaler
from sklearn.neighbors import NearestNeighbors

df = pd.read_csv("Cleaned_Electric_Vehicle_Data.csv")
print("Dataset Loaded:", df.shape)

rec_df = df[['Make', 'Model Year', 'Electric Vehicle Type', 'Electric Range', 'Base MSRP']].copy()
rec_df = rec_df.dropna().reset_index(drop=True)

enc_make = LabelEncoder()
enc_type = LabelEncoder()

rec_df['Make'] = enc_make.fit_transform(rec_df['Make'])
rec_df['Electric Vehicle Type'] = enc_type.fit_transform(rec_df['Electric Vehicle Type'])

scaler = MinMaxScaler()
scaled_numeric = scaler.fit_transform(rec_df[['Model Year', 'Electric Range', 'Base MSRP']])


final_features = pd.DataFrame(scaled_numeric, columns=['Model Year', 'Electric Range', 'Base MSRP'])
final_features['Make'] = rec_df['Make']
final_features['Electric Vehicle Type'] = rec_df['Electric Vehicle Type']


nn_model = NearestNeighbors(metric='cosine', n_neighbors=6)
nn_model.fit(final_features)

print("Nearest Neighbors Model Ready.")



def recommend_similar_ev(index, n=5):
    distances, indices = nn_model.kneighbors([final_features.iloc[index]], n_neighbors=n+1)
    
    # skip itself, return top n
    top_indices = indices[0][1:]
    
    return df.iloc[top_indices][[
        'Make', 'Model Year', 'Electric Vehicle Type',
        'Electric Range', 'Base MSRP'
    ]]

def recommend_by_preferences(min_range, max_budget, ev_type):
    filtered = df[
        (df['Electric Range'] >= min_range) &
        (df['Base MSRP'] <= max_budget) &
        (df['Electric Vehicle Type'].str.contains(ev_type, case=False))
    ]
    
    if filtered.empty:
        return "❌ No matching EVs found."
    
    return filtered.head(10)[[
        'Make', 'Model Year', 'Electric Vehicle Type',
        'Electric Range', 'Base MSRP'
    ]]


#              TEST EXAMPLES

print("\n📌 Similar EVs to index 100:")
print(recommend_similar_ev(100))

print("\n📌 Preference-based Recommendation:")
print(recommend_by_preferences(200, 40000, "Battery Electric Vehicle"))
